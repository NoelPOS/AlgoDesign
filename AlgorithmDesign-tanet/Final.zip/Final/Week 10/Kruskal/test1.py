a = list(range(1, 3+1))
print(a)